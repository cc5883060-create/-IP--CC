---
name: face-aesthetics-editor
description: Build or update a Chinese copy-driven facial-aesthetics overlay editor with reusable region presets, precise anatomical targeting, and clean image output. Use for 面部结构编辑台, 外眼眶C and related reference-region corrections, or maintaining its semantic preset library; not for medical diagnosis or surgical planning.
---

# 面部结构编辑台

维护可持续更新的面部美学叠加编辑台。包含67组方案的可运行起点，支持中文文案规则、照片定位、手动校准、纯净输出、项目与方案导入导出。

## 使用方式

- 用户已有编辑台时先定位并检查当前源文件，保留其更新、自定义方案和项目；不要用此快照覆盖较新的实现。
- 创建新编辑台时，将 `assets/editor/` 复制到任务工作区后修改。不要在已安装 skill 的资产目录里进行日常项目开发。
- 编辑部位形状或理解文案时读 [references/regions-and-semantics.md](references/regions-and-semantics.md)。实现、导出或排查时读 [references/editor-workflow.md](references/editor-workflow.md)。
- 本地HTML交付：`node scripts/build-standalone.cjs <editor-source-directory> <output.html>`。
- 修改语义后：`node scripts/check-semantics.cjs <editor-source-directory>`；新增实际失败句作为回归用例。
- 如果任务是已有照片/视频的离线成片制作，而非编辑台，当前环境存在 `face-aesthetics-tracker` 时优先采用其追踪工作流。不要用本编辑台预览冒充已逐帧审校的成片。

## 必须延续的用户偏好

1. 原始人物为底层，只加独立叠加层。保持五官、表情、肤色、质感、发型和光影，不进行瘦脸、美化或重绘。
2. 默认开启纯净画面：不新增标题、副标题、标签、引线、数字、装饰点和品牌。只保留与文案有关的轻薄区域或边界。用户明确要求标签时再开启。
3. 参考图决定位置和形态，其现成文字不是输出要求。不要自动把参考图当干净原图，已有文字/水印不会因关闭叠加标签而消失。
4. 先理解讨论的部位、关系、变化和排除项，再选图形。优先专有部位，不用泛眶周、整条下颌或整张嘴代替局部目标。一次突出1–3处。
5. 文案涉及纹路、阴影、凹陷的变浅/加深/减淡时保留证据：画外围开放标记，不在线纹上描线或铺填色。
6. 根据当前姿态仅画可见侧；不镜像补齐遮挡侧。人物左右与画面左右混淆时提示复核，不假装已知镜像关系。
7. 骨相层是艺术结构示意，不是真实骨骼重建；不输出医学诊断、治疗建议或伪精确角度。

## 验证和能力边界

更新后同时验证语义映射和可见渲染，检查眼睛、鼻孔、唇缝无遮挡，纯净模式导出无新增文字，旧草稿能补入新方案并保留自定义方案。视频还需检查前中后与转头/遮挡片段；不承诺任何素材零漂移。

资产中的语义引擎是可解释的本地规则，不是通用大模型理解。复杂省略、隐喻或歧义需复核；不要宣称100%准确。模型点位不代表可靠发际线或真实骨骼；额头上缘需人工确认。

保存/使用此 skill 不授权上传人物、发布网站或推送源码。延续用户明确选择的本地交付方式；需在线发布时依据当时授权与工具权限执行。
