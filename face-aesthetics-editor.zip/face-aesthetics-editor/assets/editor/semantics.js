/* Explicit, editable domain rules. No remote language model is used. */
window.Semantics=(()=>{
const aliases={forehead:['额头','额部','额骨','上庭'],brow:['眉弓','眉骨','眉眼','眉峰'],orbit:['眶周','眼眶','眼下','眼位','眼距','眼间距','眼角','眉眼'],temple:['颞区','太阳穴','颞部'],cheek:['颧区','颧骨','颧弓','颧颌','面中','中面部'],apple:['苹果肌','面颊'],nose:['鼻梁','鼻尖','鼻根','鼻骨','鼻背','中轴','鼻唇颏','眉鼻'],base:['鼻基底','鼻底','鼻翼','鼻唇'],lip:['嘴唇','口唇','唇部','嘴角','口周','唇周','口宽','鼻唇','唇颏','人中'],chin:['下巴','颏部','颏点','唇颏','鼻唇颏','颏骨'],jaw:['下颌','下颚','颧颌','颌缘','颌骨'],axis:['中轴线','中线']};
const signals={bone:['骨相','骨骼','骨性','骨层','透视'],region:['范围','区域','面积','体积','饱满','凹陷','圈出','面片','苹果肌'],structure:['支撑','承托','承重','支架','衔接','连接','结构线','框架'],angle:['夹角','角度','转折','拐点','折叠','前后','投射','鼻唇颏','下颌角'],grid:['比例','定位','位置','间距','宽度','三庭','眼位','中轴线','高低'],contour:['轮廓','边缘','走向','描边','曲线','下颌线','外框']};
function parse(text,library=window.PRESETS,angle='auto'){
 const pieces=String(text).replace(/不是/g,'不要').replace(/而是/g,'。重点').split(/[，。；！\n,;!]|但是|但要|而要|而只|只需/).map(x=>x.trim()).filter(Boolean);
 const rejected=[],positive=[],blocked=new Set();
 for(const p of pieces){if(/(不要|不用|无需|不必|别画|别标|不画|不想|不需要|避免|禁止|不标|不做|不看|不强调|忽略)/.test(p)){rejected.push(p);for(const [k,ws]of Object.entries(signals))if(ws.some(w=>p.includes(w)))blocked.add(k);}else positive.push(p);}
 const content=positive.join('。');
 const counts=Object.fromEntries(Object.keys(signals).map(k=>[k,0]));
 for(const [k,ws]of Object.entries(signals))for(const p of positive)for(const w of ws)if(p.includes(w))counts[k]+=w.length*(/重点|只看|主要|核心|强调/.test(p)?2:1);
 // Drawing instructions override words describing anatomy: "颧骨的范围" is a region.
 if(/结构线|画.*支架|用.*折线/.test(content))counts.structure+=25;
 if(/角度标记|画.*角|用.*弧/.test(content))counts.angle+=25;
 if(/圈出|标.*区域|半透明.*区域/.test(content))counts.region+=25;
 if(/描.*轮廓|沿.*下颌线/.test(content))counts.contour+=25;
 if(/骨相示意|骨骼透视|骨相透视/.test(content))counts.bone+=25;
 for(const k of blocked)counts[k]=-100;
 let type=Object.keys(counts).sort((a,b)=>counts[b]-counts[a])[0];if(Math.max(...Object.values(counts))<=0){const fallback=/下颌|下巴|外轮廓/.test(content)?'contour':'region';type=blocked.has(fallback)?Object.keys(counts).find(k=>!blocked.has(k)):fallback;}
 const evidence=signals[type].filter(w=>content.includes(w));
 const regions=Object.entries(aliases).map(([k,ws])=>[k,ws.reduce((n,w)=>n+(content.includes(w)?w.length:0),0)]).filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]).map(x=>x[0]);
 const ranked=library.filter(p=>!blocked.has(p.type)).map(p=>({p,score:p.keywords.reduce((n,w)=>n+(content.includes(w)?w.length*4:0),0)+p.regions.filter(r=>regions.includes(r)).length*7+(p.type===type?12:0)+(angle==='auto'||p.angles.includes(angle)?2:-12)})).sort((a,b)=>b.score-a.score);
 const uncertain=!content||(!regions.length&&Math.max(...Object.values(counts))<=0);
 if(uncertain)return {layers:[],rejected,confidence:'需补充语义',summary:'请说明关注部位及要表达的关系，例如“鼻唇颏的前后层次”。',evidence:[],warnings:['没有足够依据，未自动添加标注。'],ranked:[]};
 const best=ranked[0]?.p;
 if(!best)return {layers:[],rejected,confidence:'需人工选择',summary:'当前约束排除了全部标注形式。',evidence:[],warnings:[],ranked:[]};
 let selected=regions.length?regions.slice(0,3):best.regions;
 let layers=[{...best,type,regions:selected,id:best.id}];
 // Separate explicit clauses can each choose a different visual grammar.
 if(positive.length>1){const candidates=[];for(const p of positive){const rr=Object.entries(aliases).filter(([,ws])=>ws.some(w=>p.includes(w))).map(([k])=>k);if(!rr.length)continue;const ts=Object.entries(signals).filter(([k])=>!blocked.has(k)).map(([k,ws])=>[k,ws.reduce((n,w)=>n+(p.includes(w)?w.length:0),0)]).sort((a,b)=>b[1]-a[1]);if(ts[0]?.[1]>0)candidates.push({type:ts[0][0],regions:rr.slice(0,3)});}if(candidates.length>1&&new Set(candidates.map(x=>x.type)).size>1){let used=new Set();layers=candidates.map((c,i)=>{c.regions=c.regions.filter(r=>!used.has(r)&&used.size<3&&(used.add(r),true));return {...best,...c,id:best.id+'-'+i};}).filter(x=>x.regions.length).slice(0,3);}}
 const warnings=[];if(regions.length>3)warnings.push('涉及超过3个部位，已保留优先匹配的3处；可拆成多张。');if(/更好|理想|标准|黄金|完美|改善|提升|治疗|注射|填充/.test(content))warnings.push('只转换可见结构，不输出优劣标准或治疗效果。');if(/对比|相比|高低|前后/.test(content))warnings.push('保留比较关系；不生成改变人物后的对比图。');if(/左|右/.test(content))warnings.push('左右按画面方向解释，可在可见侧设置中核对镜像。');
 return {layers,rejected,confidence:regions.length&&evidence.length?'规则匹配明确':'建议复核',summary:layers.map(l=>l.regions.map(r=>REGIONS[r]).join('、')+' → '+TYPES[l.type]).join('；'),evidence,warnings,ranked:ranked.slice(0,3).map(x=>x.p.id)};
}
return {parse,aliases,signals};})();

// Specific anatomy wins over generic substrings. Keep negation local to its clause.
(()=>{const base=Semantics.parse;const re=/外(?:眼)?眶\s*[cｃＣC](?:\s*(?:形|型))?(?:区域|区)?/ig;
Semantics.parse=function(text,library=PRESETS,angle='auto'){
 const source=String(text).normalize('NFKC');if(!re.test(source)){re.lastIndex=0;return base(source,library,angle);}re.lastIndex=0;
 const clauses=source.replace(/而是/g,'，重点').split(/[，。；！\n,;!]|但是|但要/).filter(Boolean),cParts=[],others=[],rejected=[];let carry=false;
 for(const clause of clauses){re.lastIndex=0;const has=re.test(clause);re.lastIndex=0;
 if(has){const isNegative=/(?:不要|不想|无需|不用|别|不标|不画|不是)(?:再|去|标注|标|画|看|做|强调|圈出|左侧|右侧|左边|右边|画面|整个|这里是|这个是|\s)*外(?:眼)?眶\s*c/i.test(clause)||/外(?:眼)?眶\s*c(?:区|区域)?(?:先)?(?:不标|不画|不要标|不用画)/i.test(clause);if(isNegative){rejected.push(clause);carry=false;}else{cParts.push(clause);carry=true;}}
 else if(carry&&!Object.values(Semantics.aliases).flat().some(w=>clause.includes(w))){cParts.push(clause);}else{others.push(clause);carry=false;}}
 const context=cParts.join('，'),rest=base(others.join('，'),library,angle);if(!context){rest.rejected=[...rejected,...rest.rejected];return rest;}
 const noFill=/(不(?:要|用|需|必)?填|不(?:要|用)?铺|仅.*(?:边界|轮廓)|只.*(?:边界|轮廓)|空心|不要.*遮|别.*遮|阴影|纹理|细纹|皱纹)/.test(context),outline=noFill||/(边界|轮廓|描边)/.test(context);
 const negBone=/(不(?:要|用|需).*骨|别.*骨)/.test(context);const type=outline?'contour':(!negBone&&/骨相|骨骼|骨性/.test(context)?'bone':'region');
 const side=/双侧|两侧|左右两边/.test(context)?'both':/(?:画面|图中|图像)?右(?:侧|边|眼)?/.test(context)?'right':/(?:画面|图中|图像)?左(?:侧|边|眼)?/.test(context)?'left':'auto';
 const preset=library.find(p=>p.id===(outline?'E11':'F11'))||PRESETS.find(p=>p.id===(outline?'E11':'F11'));const layer={...preset,type,side,regions:['outerC'],noFill,semanticTarget:'outer-orbital-crescent'};
 const warnings=[...rest.warnings.filter(w=>!w.includes('没有足够依据'))];if(angle==='profile')warnings.push('侧面无法可靠显示完整外眼眶C，图层将隐藏。');if(/人物|本人|模特|她的|他的/.test(context)&&side!=='auto'&&side!=='both'){layer.side='auto';warnings.push('人物左右与镜像关系不明确，请在“可见侧”手动确认。');}else if(side==='left'||side==='right')warnings.push('已按画面'+(side==='left'?'左':'右')+'侧定位；可在可见侧设置中覆盖。');
 if(/角度|夹角/.test(context))warnings.push('外眼眶C是区域名称；仅凭该表述不生成夹角数值。');
 let usedRegions=new Set(['outerC']);const otherLayers=rest.layers.map(l=>({...l,regions:l.regions.filter(r=>!usedRegions.has(r)&&usedRegions.size<3&&(usedRegions.add(r),true))})).filter(l=>l.regions.length);const layers=[layer,...otherLayers].slice(0,3);return {layers,rejected:[...rejected,...rest.rejected],confidence:'专有区域匹配 · 已参考用户示意',summary:layers.map(l=>l.regions.map(r=>REGIONS[r]).join('、')+' → '+TYPES[l.type]+(l.side&&l.side!=='auto'?'（'+({right:'画面右侧',left:'画面左侧',both:'可见双侧'}[l.side])+'）':'')).join('；'),evidence:['外眼眶C：眉尾下方 → 外眼角外侧 → 外侧眶下',noFill?'保留纹理：不填色':'月牙区域：眼部留空'],warnings,ranked:[preset.id,...rest.ranked]};
};})();
