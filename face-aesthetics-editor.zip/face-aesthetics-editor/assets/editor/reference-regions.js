/* Specific reference regions. Reference captions are not output text. */
Object.assign(REGIONS,{nasolabial:'法令纹区域',foreheadArea:'额头区域',upperLip:'上唇',jawTurn:'下颌拐点',tearTrough:'泪沟区域'});
const referenceDefinitions=[
 ['F12','nasolabial','法令纹周边',['法令纹','鼻唇沟'],'鼻翼外侧向嘴角外侧延伸的弧带；讨论纹路深浅时用外围开放标记。'],
 ['F13','foreheadArea','额头完整区域',['额头','额部','前额'],'眉上至可见发际线之间的连贯弧形区域，发际线需人工确认。'],
 ['F14','upperLip','上唇精准边界',['上嘴唇','上唇','上口唇'],'仅定位上唇，沿唇峰及上唇边界轻描，避开下唇与口腔。'],
 ['F15','jawTurn','下颌拐点区域',['下颌拐点','下颌转折点','下颌折点'],'耳前下方到下颌缘转折的局部弯曲区域，不标整条下颌。'],
 ['F16','tearTrough','泪沟周边',['泪沟','泪槽'],'下眼睑下方的窄弧带，与外眼眶C及整个苹果肌区分。']
];
for(const [id,r,name,keywords,description]of referenceDefinitions)PRESETS.push({id,name,type:r==='upperLip'?'contour':'region',regions:[r],keywords,description,angles:r==='jawTurn'?['front','three','profile']:['front','three'],opacity:r==='upperLip'?.65:.18,avoid:'只标可见且经核对的区域；保留原始肤色纹理。',revision:3});
(()=>{const previous=Semantics.parse;Semantics.parse=function(text,library=PRESETS,angle='auto'){
 const clauses=String(text).normalize('NFKC').replace(/而是/g,'，').split(/[，。；！\n,;!]|但是/).filter(Boolean),specific=[],rest=[],rejected=[];let last=null;
 for(const c of clauses){const defs=referenceDefinitions.filter(d=>d[3].some(w=>c.includes(w)));if(!defs.length){if(last&&/只|不要填|不填|空心|边界|不遮|变浅|变淡/.test(c)&&!Object.values(Semantics.aliases).flat().some(w=>c.includes(w))){last.context+='，'+c;}else rest.push(c);continue;}
 for(const def of defs){const at=Math.min(...def[3].map(w=>c.indexOf(w)).filter(i=>i>=0));const before=c.slice(0,at),after=c.slice(at);if(/(?:不要|不想|不用|无需|别|不是|不标|不画)(?:标注|标|画|看|强调|左侧|右侧|画面|整个|\s)*$/.test(before)||/^(?:法令纹|鼻唇沟|额头|额部|前额|上嘴唇|上唇|上口唇|下颌拐点|下颌转折点|下颌折点|泪沟|泪槽)(?:先)?(?:不画|不标|不要标)/.test(after)){rejected.push(c);continue;}
 // Forehead angles and bone requests remain with their established analytical modules.
 if(def[1]==='foreheadArea'&&/眉弓|额鼻|夹角|比例|骨相|骨骼|支架|结构线/.test(c)){rest.push(c);continue;}
 last={def,context:c};specific.push(last);}}
 const base=previous(rest.join('，'),library,angle);if(!specific.length){base.rejected.push(...rejected);return base;}
 const warnings=base.warnings.filter(w=>!w.includes('没有足够依据')),seen=new Set();let built=specific.map(({def,context})=>{const [id,r]=def,preset=library.find(p=>p.id===id)||PRESETS.find(p=>p.id===id);const evidence=/纹路|深浅|变浅|变深|减淡|变淡|阴影|纹理|平滑|明显|细纹/.test(context);const hollow=evidence||/不(?:要|用)?填|不铺|只.*(?:边界|轮廓)|空心/.test(context)||r==='upperLip';const side=/双侧|两侧/.test(context)?'both':/右/.test(context)?'right':/左/.test(context)?'left':'auto';if(r==='foreheadArea')warnings.push('额头上缘不是自动识别的真实发际线；确认后才显示，请手动校准。');return {...preset,side,noFill:hollow,openBoundary:evidence&&(r==='nasolabial'||r==='tearTrough'),type:hollow?'contour':'region',semanticTarget:r};});
 const layers=[...built,...base.layers].map(l=>({...l,regions:l.regions.filter(r=>!seen.has(r)&&seen.size<3&&(seen.add(r),true))})).filter(l=>l.regions.length).slice(0,3);if(specific.length+base.layers.length>3)warnings.push('一次最多突出3处，请把其余部位拆到下一张。');
 return {...base,layers,rejected:[...rejected,...base.rejected],summary:layers.map(l=>l.regions.map(r=>REGIONS[r]).join('、')+' → '+(l.openBoundary?'外围开放标记':TYPES[l.type])).join('；'),confidence:'专有区域规则 · 参考图定位',evidence:['按具体部位定位','纹路与阴影变化保留内部细节'],warnings,ranked:layers.map(l=>l.id)};
 };})();
