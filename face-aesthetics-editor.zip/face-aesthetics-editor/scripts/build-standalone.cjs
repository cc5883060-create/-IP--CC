const fs=require('node:fs'),path=require('node:path');
const [source,output]=process.argv.slice(2);if(!source||!output)throw Error('Usage: node build-standalone.cjs SOURCE_DIRECTORY OUTPUT.html');
let html=fs.readFileSync(path.join(source,'index.html'),'utf8');
const css=fs.readFileSync(path.join(source,'style.css'),'utf8');html=html.replace('<link rel="stylesheet" href="style.css">',()=>'<style>'+css+'</style>');
for(const f of ['library.js','semantics.js','reference-regions.js','app.js']){const js=fs.readFileSync(path.join(source,f),'utf8').replace(/<\/script/gi,'<\\/script');const tag='<script src="'+f+'"></script>';if(!html.includes(tag))throw Error('Missing script: '+f);html=html.replace(tag,()=>'<script>'+js+'</script>');}
fs.mkdirSync(path.dirname(path.resolve(output)),{recursive:true});fs.writeFileSync(output,html);console.log('Built '+path.resolve(output));
